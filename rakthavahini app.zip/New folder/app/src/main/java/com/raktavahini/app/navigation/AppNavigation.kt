package com.raktavahini.app.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.raktavahini.app.ui.screens.*
import com.raktavahini.app.viewmodel.DonorViewModel

object Routes {
    const val HOME = "home"
    const val REGISTER = "register"
    const val SEARCH = "search"
    const val LIST = "list"
    const val DONATED = "donated"   // ❤️ NEW ROUTE
}

@Composable
fun AppNavigation() {

    val navController = rememberNavController()
    val donorViewModel: DonorViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = Routes.HOME
    ) {

        composable(Routes.HOME) {
            HomeScreen(navController, donorViewModel)
        }

        composable(Routes.REGISTER) {
            RegisterScreen(navController, donorViewModel)
        }

        composable(Routes.SEARCH) {
            SearchScreen(navController, donorViewModel)
        }

        composable(Routes.LIST) {
            DonorListScreen(
                navController = navController,
                viewModel = donorViewModel
            )
        }

        // ❤️ DONATED SCREEN ADDED
        composable(Routes.DONATED) {
            DonatedScreen(viewModel = donorViewModel)
        }
    }
}
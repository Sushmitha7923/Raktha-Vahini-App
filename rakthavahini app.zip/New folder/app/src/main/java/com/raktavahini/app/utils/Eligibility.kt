package com.raktavahini.app.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val NINETY_DAYS_MILLIS = 90L * 24 * 60 * 60 * 1000

fun isEligible(lastDonationDate: Long): Boolean {
    if (lastDonationDate == 0L) return true

    val now = System.currentTimeMillis()
    return (now - lastDonationDate) >= NINETY_DAYS_MILLIS
}

fun nextEligibleDate(lastDonationDate: Long): String {
    if (lastDonationDate == 0L) return "Now Eligible"

    val nextDate = Date(lastDonationDate + NINETY_DAYS_MILLIS)

    return SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        .format(nextDate)
}
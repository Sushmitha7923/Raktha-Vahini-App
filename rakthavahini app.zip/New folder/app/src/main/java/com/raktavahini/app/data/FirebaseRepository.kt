package com.raktavahini.app.data

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.raktavahini.app.model.Donation
import com.raktavahini.app.model.Donor

class FirebaseRepository {

    private val db = FirebaseFirestore.getInstance()

    // -----------------------------
    // 🩸 ADD DONOR
    // -----------------------------
    fun addDonor(
        donor: Donor,
        onSuccess: () -> Unit = {},
        onFailure: (Exception) -> Unit = {}
    ) {
        db.collection("donors")
            .add(donor)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure(it) }
    }

    // -----------------------------
    // ✏️ UPDATE DONOR
    // -----------------------------
    fun updateDonor(
        donorId: String,
        donor: Donor,
        onSuccess: () -> Unit = {},
        onFailure: (Exception) -> Unit = {}
    ) {
        db.collection("donors")
            .document(donorId)
            .set(donor)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure(it) }
    }

    // -----------------------------
    // 🗑 DELETE DONOR
    // -----------------------------
    fun deleteDonor(
        donorId: String,
        onSuccess: () -> Unit = {},
        onFailure: (Exception) -> Unit = {}
    ) {
        db.collection("donors")
            .document(donorId)
            .delete()
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure(it) }
    }

    // -----------------------------
    // 📋 GET ALL DONORS
    // -----------------------------
    fun getAllDonors(
        onResult: (List<Donor>) -> Unit,
        onFailure: (Exception) -> Unit = {}
    ) {
        db.collection("donors")
            .get()
            .addOnSuccessListener { result ->
                val list = result.documents.mapNotNull {
                    it.toObject(Donor::class.java)
                }
                onResult(list)
            }
            .addOnFailureListener { onFailure(it) }
    }

    // -----------------------------
    // 🩸 GET BY BLOOD GROUP
    // -----------------------------
    fun getDonorsByBloodGroup(
        bloodGroup: String,
        onResult: (List<Donor>) -> Unit,
        onFailure: (Exception) -> Unit = {}
    ) {
        db.collection("donors")
            .whereEqualTo("bloodGroup", bloodGroup)
            .get()
            .addOnSuccessListener { result ->
                val list = result.documents.mapNotNull {
                    it.toObject(Donor::class.java)
                }
                onResult(list)
            }
            .addOnFailureListener { onFailure(it) }
    }

    // -----------------------------
    // 🚀 SEARCH (BLOOD + LOCATION)
    // -----------------------------
    fun searchDonors(
        bloodGroup: String,
        location: String,
        onResult: (List<Donor>) -> Unit
    ) {
        db.collection("donors")
            .whereEqualTo("bloodGroup", bloodGroup)
            .get()
            .addOnSuccessListener { result ->

                val donors = result.documents.mapNotNull {
                    it.toObject(Donor::class.java)
                }

                val filtered = donors.filter {
                    it.location.contains(location, ignoreCase = true)
                }

                onResult(filtered)
            }
    }

    // -----------------------------
    // ❤️ MARK AS DONATED
    // -----------------------------
    fun markAsDonated(
        donorId: String,
        onSuccess: () -> Unit = {},
        onFailure: (Exception) -> Unit = {}
    ) {
        db.collection("donors")
            .document(donorId)
            .update(
                mapOf(
                    "isDonated" to true,
                    "readyToDonate" to false,
                    "available" to false,
                    "lastDonationDate" to System.currentTimeMillis()
                )
            )
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure(it) }
    }

    // -----------------------------
    // 🩸 ELIGIBLE DONORS
    // -----------------------------
    fun getEligibleDonors(
        bloodGroup: String,
        onResult: (List<Donor>) -> Unit
    ) {
        db.collection("donors")
            .whereEqualTo("bloodGroup", bloodGroup)
            .whereEqualTo("readyToDonate", true)
            .get()
            .addOnSuccessListener { result ->

                val donors = result.documents.mapNotNull {
                    it.toObject(Donor::class.java)
                }

                val eligible = donors.filter {
                    isEligible(it.lastDonationDate)
                }

                onResult(eligible)
            }
    }

    // -----------------------------
    // 📍 SEARCH BY LOCATION ONLY
    // -----------------------------
    fun searchByLocation(
        location: String,
        onResult: (List<Donor>) -> Unit
    ) {
        db.collection("donors")
            .get()
            .addOnSuccessListener { result ->

                val donors = result.documents.mapNotNull {
                    it.toObject(Donor::class.java)
                }

                val filtered = donors.filter {
                    it.location.contains(location, ignoreCase = true)
                }

                onResult(filtered)
            }
    }

    // -----------------------------
    // ➕ ADD DONATION
    // -----------------------------
    fun addDonation(
        donation: Donation,
        onSuccess: () -> Unit = {},
        onFailure: (Exception) -> Unit = {}
    ) {
        db.collection("donations")
            .add(donation)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure(it) }
    }

    // -----------------------------
    // 📋 GET ALL DONATIONS
    // -----------------------------
    fun getDonations(
        onResult: (List<Donation>) -> Unit,
        onFailure: (Exception) -> Unit = {}
    ) {
        db.collection("donations")
            .orderBy("date", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { result ->

                val list = result.documents.mapNotNull { doc ->
                    val donation = doc.toObject(Donation::class.java)
                    donation?.copy(id = doc.id)
                }

                onResult(list)
            }
            .addOnFailureListener {
                onFailure(it)
            }
    }

    // -----------------------------
    // 👤 DONOR DONATIONS
    // -----------------------------
    fun getDonationsByDonor(
        donorId: String,
        onResult: (List<Donation>) -> Unit
    ) {
        db.collection("donations")
            .whereEqualTo("donorId", donorId)
            .get()
            .addOnSuccessListener { result ->
                val list = result.documents.mapNotNull {
                    it.toObject(Donation::class.java)
                }
                onResult(list)
            }
    }

    // -----------------------------
    // ❤️ GET DONATED DONORS (FIXED)
    // -----------------------------
    fun getDonatedDonors(
        onResult: (List<Donor>) -> Unit,
        onFailure: (Exception) -> Unit = {}
    ) {
        db.collection("donors")
            .whereEqualTo("isDonated", true)
            .get()
            .addOnSuccessListener { result ->

                val list = result.documents.mapNotNull { doc ->
                    val donor = doc.toObject(Donor::class.java)
                    donor?.copy(id = doc.id)
                }

                onResult(list)
            }
            .addOnFailureListener {
                onFailure(it)
            }
    }
    // -----------------------------
    // 🧠 ELIGIBILITY LOGIC
    // -----------------------------
    private fun isEligible(lastDonationDate: Long): Boolean {

        if (lastDonationDate == 0L) return true

        val now = System.currentTimeMillis()
        val ninetyDays = 90L * 24 * 60 * 60 * 1000

        return (now - lastDonationDate) >= ninetyDays
    }
}
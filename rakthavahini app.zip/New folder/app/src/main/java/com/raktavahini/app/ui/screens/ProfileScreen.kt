package com.raktavahini.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

import com.raktavahini.app.model.Donor

@Composable
fun ProfileScreen(
    donor: Donor
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "👤 Donor Profile",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 6.dp
            )
        ) {

            Column(
                modifier = Modifier.padding(20.dp)
            ) {

                ProfileItem(
                    label = "Name",
                    value = donor.name
                )

                ProfileItem(
                    label = "Phone",
                    value = donor.phone
                )

                ProfileItem(
                    label = "Blood Group",
                    value = donor.bloodGroup
                )

                ProfileItem(
                    label = "Location",
                    value = donor.location
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text =
                        if (donor.available)
                            "Available to Donate ✅"
                        else
                            "Currently Unavailable ❌",

                    color =
                        if (donor.available)
                            Color(0xFF2E7D32)
                        else
                            Color.Red,

                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ProfileItem(
    label: String,
    value: String
) {

    Column(
        modifier = Modifier.padding(vertical = 6.dp)
    ) {

        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = Color.Gray
        )

        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium
        )
    }
}
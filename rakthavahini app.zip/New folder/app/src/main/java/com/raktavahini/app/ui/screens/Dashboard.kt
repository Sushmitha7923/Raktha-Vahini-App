package com.raktavahini.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.raktavahini.app.navigation.Routes
import com.raktavahini.app.viewmodel.DonorViewModel

@Composable
fun Dashboard(
    viewModel: DonorViewModel,
    navController: NavController
) {

    val donors = viewModel.donorList.value
    val donations = viewModel.donationList.value

    // 🔥 Auto refresh data when screen opens
    LaunchedEffect(Unit) {
        viewModel.fetchDonations()
        viewModel.searchDonors("", "") // optional refresh (or remove if not needed)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "📊 Dashboard",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(6.dp)
        ) {

            Column(modifier = Modifier.padding(16.dp)) {

                Text("👥 Total Donors: ${donors.size}")
                Text("🩸 Total Donations: ${donations.size}")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 🔥 NAVIGATION BUTTONS

        Button(
            onClick = { navController.navigate(Routes.REGISTER) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Register Donor")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = { navController.navigate(Routes.SEARCH) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Search Donor")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = { navController.navigate(Routes.LIST) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Donation List")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = { navController.navigate(Routes.DONATED) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Donated Donors")
        }
    }
}
package com.raktavahini.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.raktavahini.app.viewmodel.DonorViewModel

@Composable
fun DonatedScreen(viewModel: DonorViewModel) {

    val donors = viewModel.donatedList.value

    LaunchedEffect(Unit) {
        viewModel.fetchDonatedDonors()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "❤️ Donated Donors",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn {
            items(donors) { donor ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {

                    Column(modifier = Modifier.padding(12.dp)) {

                        Text("Name: ${donor.name}")
                        Text("Blood Group: ${donor.bloodGroup}")
                        Text("Location: ${donor.location}")

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "DONATED ❤️",
                            color = Color.Red
                        )
                    }
                }
            }
        }
    }
}
package com.raktavahini.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.raktavahini.app.navigation.AppNavigation
import com.raktavahini.app.ui.theme.RaktaVahiniTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            RaktaVahiniTheme {
                AppNavigation()
            }
        }
    }
}
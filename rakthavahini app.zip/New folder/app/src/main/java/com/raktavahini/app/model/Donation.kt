package com.raktavahini.app.model

data class Donation(
    val id: String = "",
    val donorId: String = "",   // IMPORTANT
    val donorName: String = "",
    val bloodGroup: String = "",
    val date: Long = 0L,
    val hospital: String = ""
)
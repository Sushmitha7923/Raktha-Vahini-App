package com.raktavahini.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = RedPrimary,
    secondary = DarkRed,
    background = White,
    surface = White,
    error = ErrorRed
)

private val DarkColorScheme = darkColorScheme(
    primary = RedPrimary,
    secondary = DarkRed,
    background = DarkSurface,
    surface = DarkSurface,
    error = ErrorRed
)

@Composable
fun RaktaVahiniTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {

    val colorScheme = when {
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
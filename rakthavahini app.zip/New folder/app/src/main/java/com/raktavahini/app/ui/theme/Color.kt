package com.raktavahini.app.ui.theme

import androidx.compose.ui.graphics.Color

// Primary brand colors (Blood donation red theme)
val RedPrimary = Color(0xFFD32F2F)
val DarkRed = Color(0xFFB71C1C)
val LightRed = Color(0xFFFFCDD2)

// Secondary / Accent
val DeepRedAccent = Color(0xFF8E0000)

// Background & Surface
val White = Color(0xFFFFFFFF)
val LightGray = Color(0xFFF5F5F5)
val DarkSurface = Color(0xFF121212)

// Text colors
val Black = Color(0xFF000000)
val Gray = Color(0xFF757575)

// Status colors
val SuccessGreen = Color(0xFF2E7D32)
val ErrorRed = Color(0xFFD50000)


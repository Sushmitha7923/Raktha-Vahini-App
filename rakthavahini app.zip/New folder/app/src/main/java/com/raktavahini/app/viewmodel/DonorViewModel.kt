package com.raktavahini.app.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.raktavahini.app.data.FirebaseRepository
import com.raktavahini.app.model.Donation
import com.raktavahini.app.model.Donor

class DonorViewModel : ViewModel() {

    private val repository = FirebaseRepository()

    // 🩸 Donors list
    val donorList = mutableStateOf<List<Donor>>(emptyList())

    // 📋 Donations list
    val donationList = mutableStateOf<List<Donation>>(emptyList())


    // --------------------------
    // 🩸 REGISTER DONOR
    // -----------------------------
    fun registerDonor(donor: Donor) {
        repository.addDonor(donor)
    }

    // -----------------------------
    // 🔍 SEARCH DONORS (BLOOD + LOCATION)
    // -----------------------------
    fun searchDonors(bloodGroup: String, location: String) {
        repository.searchDonors(bloodGroup, location) { list ->
            donorList.value = list
        }
    }

    // -----------------------------
    // 📋 ALL DONATIONS
    // -----------------------------
    fun fetchDonations() {
        repository.getDonations(
            onResult = { list ->
                donationList.value = list
            },
            onFailure = { error ->
                println("Donation fetch error: ${error.message}")
            }
        )
    }

    // -----------------------------
    // 👤 DONOR DONATIONS
    // -----------------------------
    fun fetchDonationsByDonor(donorId: String) {
        repository.getDonationsByDonor(donorId) { list ->
            donationList.value = list
        }
    }

    // -----------------------------
    // ➕ ADD DONATION
    // -----------------------------
    fun addDonation(donation: Donation) {
        repository.addDonation(donation)
    }

    // -----------------------------
    // ❤️ MARK DONOR AS DONATED (NEW FEATURE)
    // -----------------------------
    fun markDonorAsDonated(donorId: String) {
        repository.markAsDonated(donorId)
    }

    val donatedList = mutableStateOf<List<Donor>>(emptyList())

    fun fetchDonatedDonors() {
        repository.getDonatedDonors(
            onResult = { list ->
                donatedList.value = list
            },
            onFailure = { error ->
                println(error.message)
            }
        )
    }
}
package com.raktavahini.app.model

data class Donor(

    // 🆔 Firestore document ID
    val id: String = "",

    // 👤 Full name
    val name: String = "",

    // 📞 Phone number
    val phone: String = "",

    // 📧 Email address
    val email: String = "",

    // 🩸 Blood group
    val bloodGroup: String = "",

    // 📍 Location / City
    val location: String = "",

    // 📅 Last donation date (timestamp)
    val lastDonationDate: Long = 0L,

    // ✅ Ready to donate now
    val available: Boolean = true,

    // 🚑 Emergency availability
    val readyToDonate: Boolean = true,

    // 🧑 Age
    val age: Int = 18,

    // ⚧ Gender
    val gender: String = "",

    // 📝 Optional medical notes
    val medicalNotes: String = "",

    // ❤️ NEW: donation status
    val isDonated: Boolean = false
)